﻿using System;
using System.Collections.Generic;
using System.Data.Entity;

namespace Mvc3AppCodeFirst.Models
{
    public class ProductContext : DbContext
    {
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }

        // Code First Fluent API
        //protected override void OnModelCreating(DbModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<Supplier>()
        //        .Property(s => s.Name)
        //        .IsRequired();
        //}
    }
}