﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Mvc3AppCodeFirst.Models
{
    public class Category
    {
        //[Key]
        //[ForeignKey]
        public int CategoryId { get; set; }

        [Required]
        [StringLength(250)]
        public string Name { get; set; }

        [Timestamp]
        public byte[] TimeStamp { get; set; }

        [Column("Lalala")]
        public int LaLa { get; set; }

        [NotMapped]
        public string FormattedName
        {
            get { return "-->> " + Name + " <<--"; }
        }

        public virtual ICollection<Product> Products { get; set; }
    }
}