﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc3AppCodeFirst.Models;

namespace Mvc3AppCodeFirst.Controllers
{
    public class CategoryController : Controller
    {
        public ActionResult Index()
        {
            IEnumerable<Category> categories = null;
            using (var context = new ProductContext())
            {
                categories = context.Categories.ToList();
            }

            return View(categories);
        }

        public ActionResult Create()
        {
            return View();
        } 

        [HttpPost]
        public ActionResult Create(Category category)
        {
            try
            {
                using (var context = new ProductContext())
                {
                    context.Categories.Add(category);
                    int recordsAffected = context.SaveChanges();

                    TempData["Info"] = string.Format("Saved {0} entities to the database.", recordsAffected);
                }

                return RedirectToAction("Index");
            }
            catch(Exception ex)
            {
                return View();
            }
        }
    }
}
